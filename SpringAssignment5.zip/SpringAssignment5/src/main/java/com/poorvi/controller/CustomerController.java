package com.poorvi.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.poorvi.bean.CustomerBean;
import com.poorvi.model.Customer;
import com.poorvi.service.CustomerService;

@Controller
public class CustomerController {
	@Autowired
	private CustomerService CustomerService;
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveCustomer(@ModelAttribute("command") CustomerBean CustomerBean, 
			BindingResult result) {
		Customer customer = prepareModel(CustomerBean);
		CustomerService.addCustomer(customer);
		return new ModelAndView("redirect:/add.html");
	}

	@RequestMapping(value="/customers", method = RequestMethod.GET)
	public ModelAndView listCustomers() {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("customers",  prepareListofBean(CustomerService.listCustomers()));
		return new ModelAndView("customersList", model);
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addCustomer(@ModelAttribute("command")  CustomerBean CustomerBean,
			BindingResult result) 
	{
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("customers",  prepareListofBean(CustomerService.listCustomers()));
		return new ModelAndView("addCustomer", model);
	}
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("index");
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView editCustomer(@ModelAttribute("command")  CustomerBean CustomerBean,
			BindingResult result) {
		CustomerService.deleteCustomer(prepareModel(CustomerBean));
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("customer", null);
		model.put("customers",  prepareListofBean(CustomerService.listCustomers()));
		return new ModelAndView("addCustomer", model);
	}
	
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView deleteCustomer(@ModelAttribute("command")  CustomerBean CustomerBean,
			BindingResult result)
	{
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("customer", prepareCustomerBean(CustomerService.getCustomer(CustomerBean.getId())));
		model.put("customers",  prepareListofBean(CustomerService.listCustomers()));
		return new ModelAndView("addCustomer", model);
	}
	
	
	
	
	private Customer prepareModel(CustomerBean CustomerBean){
		Customer customer = new Customer();
		
		customer.setName(CustomerBean.getName());
		customer.setAddress(CustomerBean.getAddress());
		customer.setAge(CustomerBean.getAge());
		customer.setBalance(CustomerBean.getBalance());
		customer.setCompanyName(CustomerBean.getCompanyName());
		customer.setEmail(CustomerBean.getEmail());
		customer.setPhone(CustomerBean.getPhone());
		customer.setAccno(CustomerBean.getId());
		CustomerBean.setId(null);
		return customer;
	}
	
	private List<CustomerBean> prepareListofBean(List<Customer> customers){
		List<CustomerBean> beans = null;
		if(customers != null && !customers.isEmpty()){
			beans = new ArrayList<CustomerBean>();
			CustomerBean bean = null;
			for(Customer customer : customers){
				bean = new CustomerBean();
				bean.setName(customer.getName());
				bean.setAge(customer.getAge());
				bean.setBalance(customer.getBalance());
				bean.setAddress(customer.getAddress());
				bean.setEmail(customer.getEmail());
				bean.setPhone(customer.getPhone());
				bean.setId(customer.getAccno());
				bean.setCompanyName(customer.getCompanyName());
				beans.add(bean);
			}
		}
		return beans;
	}
	
	private CustomerBean prepareCustomerBean(Customer customer){
		CustomerBean bean = new CustomerBean();
		
		bean.setName(customer.getName());
		bean.setAge(customer.getAge());
		bean.setBalance(customer.getBalance());
		bean.setAddress(customer.getAddress());
		bean.setEmail(customer.getEmail());
		bean.setPhone(customer.getPhone());
		bean.setId(customer.getAccno());
		bean.setCompanyName(customer.getCompanyName());
		return bean;
	}
}
