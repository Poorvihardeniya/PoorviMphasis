package com.poorvi.service;

import java.util.List;


import com.poorvi.model.Customer;

public interface CustomerService {
	public void addCustomer(Customer customer);

	public List<Customer> listCustomers();
	
	public Customer getCustomer(int accno);
	
	public void deleteCustomer(Customer customer);

}
