package com.poorvi.dao;

import java.util.List;

import com.poorvi.model.Customer;
public interface Customerdao {
	public void addCustomer(Customer customer);

	public List<Customer> listCustomers();
	
	public Customer getCustomer(int accno);
	
	public void deleteCustomer(Customer customer);
}
