package com.poorvi.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.poorvi.model.Customer;

 
@Repository("Customerdao")
public class Customerdaoml implements Customerdao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void addCustomer(Customer customer) {
		sessionFactory.getCurrentSession().saveOrUpdate(customer);
	}

//	@SuppressWarnings("unchecked")
	public List<Customer> listCustomers() 
	{
		return (List<Customer>) sessionFactory.openSession().createCriteria(Customer.class).list();
	}

	public Customer getCustomer(int accno) {
		return (Customer) sessionFactory.getCurrentSession().get(Customer.class, accno);
	}

	public void deleteCustomer(Customer customer) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM BANKNEW WHERE ACCNO = "+customer.getAccno()).executeUpdate();
	}

	
}

